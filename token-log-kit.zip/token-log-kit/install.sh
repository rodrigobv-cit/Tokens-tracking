#!/usr/bin/env bash
# Installs the token-log kit into ~/.claude (hook, skill, slash commands, settings).
# Safe to re-run. Usage: bash install.sh [--no-settings]
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
EDIT_SETTINGS=1
[ "${1:-}" = "--no-settings" ] && EDIT_SETTINGS=0

command -v python3 >/dev/null 2>&1 || { echo "python3 is required (hook and reader are Python)." >&2; exit 1; }

echo "Installing into $CLAUDE_DIR"
mkdir -p "$CLAUDE_DIR/hooks" "$CLAUDE_DIR/skills" "$CLAUDE_DIR/commands"

install -m 755 "$SRC/hooks/log_tokens.py" "$CLAUDE_DIR/hooks/log_tokens.py"
rm -rf "$CLAUDE_DIR/skills/token-log"
cp -R "$SRC/skills/token-log" "$CLAUDE_DIR/skills/token-log"
chmod +x "$CLAUDE_DIR/skills/token-log/scripts/read_log.py"
cp "$SRC/commands/"token-*.md "$CLAUDE_DIR/commands/"
echo "  hook:     $CLAUDE_DIR/hooks/log_tokens.py"
echo "  skill:    $CLAUDE_DIR/skills/token-log/"
echo "  commands: /token-start /token-end /token-span /token-report"

# Slash commands call the reader by its ~/.claude path; point them at a custom dir if needed.
if [ "$CLAUDE_DIR" != "$HOME/.claude" ]; then
  sed -i.bak "s#~/.claude#$CLAUDE_DIR#g" "$CLAUDE_DIR"/commands/token-*.md && rm -f "$CLAUDE_DIR"/commands/token-*.md.bak
fi

if [ "$EDIT_SETTINGS" -eq 1 ]; then
  python3 "$SRC/tools/settings_hooks.py" add "$CLAUDE_DIR/settings.json" \
    "python3 $CLAUDE_DIR/hooks/log_tokens.py"
else
  echo "Skipped settings.json. Merge settings.snippet.json by hand to enable logging."
fi

echo
echo "Done. Restart Claude Code, run any tool, then try:"
echo "  python3 $CLAUDE_DIR/skills/token-log/scripts/read_log.py --summary"
echo "Log file: ${CLAUDE_TOKEN_LOG:-$CLAUDE_DIR/token-log.jsonl}"
