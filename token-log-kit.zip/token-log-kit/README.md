# token-log-kit

Logs real token usage per tool call in Claude Code, lets Claude read it back,
and measures tokens consumed between a start and an end marker.

## Install

### Easiest: the single-file installer (macOS, Linux, Windows)

`install_token_log.py` is one self-contained file (the kit is embedded and
verified by SHA-256). Nothing to unzip:

```bash
python3 install_token_log.py              # install or update
python3 install_token_log.py --dry-run    # preview, change nothing
python3 install_token_log.py --check      # what is installed, are hooks registered
python3 install_token_log.py --uninstall  # remove (keeps your log)
python3 install_token_log.py --uninstall --purge --yes   # also delete log and reports
```

On Windows use `python` or `py` instead of `python3`. Options: `--config-dir DIR`,
`--python CMD`, `--no-settings`, `--no-test`. It validates `settings.json` before
touching anything, backs it up before changing it, picks a working Python
interpreter by actually running the hook, then runs an end-to-end self-test
(hook, reader, cost report). If the self-test fails it installs the files but does
not register the hooks, and says why. Windows support is untested; if something
breaks there, `--python` and `--no-settings` are your escape hatches.

Rebuild it after editing the kit (for example `pricing.json`):
`python3 tools/build_installer.py`.

### Alternative: from the unzipped folder

```bash
bash install.sh
```

Then restart Claude Code. The shell installer:

- copies the hook to `~/.claude/hooks/log_tokens.py`
- copies the skill to `~/.claude/skills/token-log/`
- copies `/token-start`, `/token-end`, `/token-span`, `/token-report` to `~/.claude/commands/`
- merges the PostToolUse and Stop hooks into `~/.claude/settings.json`
  (keeps your other settings, writes a timestamped backup, safe to re-run)

Options: `bash install.sh --no-settings` skips the settings merge (use
`settings.snippet.json` by hand). `CLAUDE_CONFIG_DIR` overrides `~/.claude`.

Requires: bash and python3 (standard library only).

## Use

Ask: "what was the last tool called and its tokens?" or run `/token-log`.

Measure a stretch of work:

```
/token-start refactor      # optional name, default is "default"
... do the work ...
/token-end refactor        # prints tokens consumed between the marks
```

`/token-span [name]` shows the running total without closing the span.
The report also lists the skills used in the window, with the approximate
context each one added (Skill tool calls, and reads of any `SKILL.md`).

`/token-report [name]` writes a full markdown report for the window: skills in
sequence, total window time (active vs idle), Claude Code permission mode,
model, effort level, token totals, prompt caching (on/off, TTL split, hit rate,
effective vs uncached tokens), thinking, version, token-related env vars,
subagent calls, possible compaction and the tool flow.
Saved to `~/.claude/token-reports/`.

The report includes a **skills flow** and a **tool flow**: Mermaid diagrams
(rendered by GitHub, VS Code's Markdown preview and many other viewers; elsewhere
you see the diagram source) with the time, context growth and output tokens of
every step, plus plain tables with the same facts.

It also estimates **cost** and gives **optimization suggestions**:

- Cost is priced per message with that message's own model, using the list
  prices in `skills/token-log/pricing.json` (official pricing page, retrieved
  2026-10-31). Cache read and write prices differ per model, and Haiku 5.5 has a
  higher tier above 100K prompt tokens; both are handled. Prices change: edit the
  file, or point `CLAUDE_TOKEN_PRICING` at your own copy. A model missing from the
  table is reported as "Not priced" rather than guessed.
- On a Pro/Max/Team subscription you are not billed per token, so read the cost
  as what the same usage would cost at API prices. It excludes fast mode,
  data-residency and batch multipliers and server-side web tool fees.
- Suggestions are rule-based and only fire on evidence in the window (cache
  expiry during pauses, mid-task model switch, compaction, heavy skills, big tool
  outputs, output-heavy cost, large model on routine work, Haiku 5.5 over 100K).
  Each states what it measured and what to do. They are heuristics from one
  window, not guarantees.

What is and is not visible: effort level and permission mode come from the hook
payload; model, cache TTL split and thinking blocks come from the transcript;
caching and thinking env vars are read from the hook's environment. Keys that
exist only in settings.json (for example `promptCacheTtl`) are not visible.
Manual: `python3 ~/.claude/skills/token-log/scripts/read_log.py --summary`

## Uninstall

```bash
bash uninstall.sh          # keeps your log
bash uninstall.sh --purge  # also deletes the log
```

## Notes

- Log: `~/.claude/token-log.jsonl` (set `CLAUDE_TOKEN_LOG` to move it).
- Numbers come from the `usage` field of the session transcript, so they are exact.
- The hook never blocks Claude: errors are swallowed and it always exits 0.
- The log grows without bound; rotate or delete it whenever you like.

## Layout

```
install_token_log.py             single-file installer (kit embedded)
install.sh / uninstall.sh        shell installer for the unzipped folder
tools/build_installer.py         rebuilds install_token_log.py from this folder
tools/installer_template.py      installer source
tools/settings_hooks.py          settings.json merge helper (shell installer)
hooks/log_tokens.py              the logging hook
skills/token-log/                skill, pricing.json, scripts/ (read_log.py, costing.py, advice.py)
commands/token-*.md              slash commands
settings.snippet.json            manual alternative to the merge
examples/sample-report.md        what /token-report produces (synthetic data)
```
