#!/usr/bin/env python3
"""token-log kit installer (single file, no dependencies beyond Python 3.8+).

Installs a Claude Code hook that logs real token usage per tool call, the
`token-log` skill (reports with cost, skills flow, tool flow, suggestions) and
the /token-start, /token-end, /token-span, /token-report slash commands.

Usage:
  python3 install_token_log.py              install or update
  python3 install_token_log.py --check      show what is installed
  python3 install_token_log.py --dry-run    show what would change, change nothing
  python3 install_token_log.py --uninstall  remove (keeps your log)
  python3 install_token_log.py --uninstall --purge --yes   also delete log and reports

Options:
  --config-dir DIR   Claude config folder (default: $CLAUDE_CONFIG_DIR or ~/.claude)
  --python CMD       interpreter the hook should use (default: first of python3,
                     python, this interpreter that passes the self-test)
  --no-settings      do not touch settings.json (merge the hooks by hand)
  --no-test          skip the end-to-end self-test

Version __VERSION__, built __BUILT__. The embedded payload is verified by SHA-256.
"""
import argparse
import base64
import copy
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

VERSION = "__VERSION__"
BUILT = "__BUILT__"
SHA256 = "__SHA256__"
MARKER = "log_tokens.py"
EVENTS = ["PostToolUse", "Stop"]
IS_WINDOWS = os.name == "nt"

PAYLOAD = """
__PAYLOAD__
"""


# ---------------------------------------------------------------- payload
def open_payload():
    data = base64.b64decode("".join(PAYLOAD.split()))
    if hashlib.sha256(data).hexdigest() != SHA256:
        sys.exit("Installer payload is corrupted (checksum mismatch). Download the installer again.")
    return zipfile.ZipFile(io.BytesIO(data))


def safe_target(cfg, name):
    """Map a zip entry to a path inside cfg; refuse anything that escapes it."""
    parts = Path(name).parts
    if not parts or ".." in parts or Path(name).is_absolute():
        sys.exit(f"Refusing unsafe path in payload: {name}")
    return cfg.joinpath(*parts)


# ---------------------------------------------------------------- helpers
def config_dir(args):
    raw = args.config_dir or os.environ.get("CLAUDE_CONFIG_DIR") or str(Path.home() / ".claude")
    return Path(raw).expanduser().resolve()


def q(text):
    text = str(text)
    return f'"{text}"' if " " in text else text


def log_path(cfg):
    return Path(os.environ.get("CLAUDE_TOKEN_LOG", cfg / "token-log.jsonl"))


def say(msg=""):
    print(msg)


# ---------------------------------------------------------------- settings.json
def load_settings(path):
    if path.exists() and path.read_text(encoding="utf-8").strip():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            sys.exit(f"{path} is not valid JSON ({e}).\nFix it first, or re-run with --no-settings. Nothing was changed.")
    return {}


def has_ours(group):
    return any(MARKER in h.get("command", "") for h in group.get("hooks", []))


def add_hooks(settings, command):
    hooks = settings.setdefault("hooks", {})
    changed = False
    for event in EVENTS:
        groups = hooks.setdefault(event, [])
        for g in groups:
            if has_ours(g):  # already registered: refresh the command in case the interpreter changed
                for h in g["hooks"]:
                    if MARKER in h.get("command", "") and h.get("command") != command:
                        h["command"] = command
                        changed = True
                break
        else:
            group = {"hooks": [{"type": "command", "command": command}]}
            if event == "PostToolUse":
                group["matcher"] = "*"
            groups.append(group)
            changed = True
    return changed


def remove_hooks(settings):
    hooks = settings.get("hooks", {})
    changed = False
    for event in list(hooks):
        kept = []
        for g in hooks[event]:
            if has_ours(g):
                changed = True
                rest = [h for h in g["hooks"] if MARKER not in h.get("command", "")]
                if rest:
                    kept.append(dict(g, hooks=rest))
            else:
                kept.append(g)
        if kept:
            hooks[event] = kept
        else:
            del hooks[event]
    if "hooks" in settings and not settings["hooks"]:
        del settings["hooks"]
    return changed


def save_settings(path, settings):
    if path.exists():
        backup = path.with_name(f"{path.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(path, backup)
        say(f"  backup:   {backup}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


# ---------------------------------------------------------------- self-test
def self_test(cfg, py):
    """Run the installed hook and reader end to end on a throwaway transcript and log."""
    exe = shutil.which(py) or (py if Path(py).exists() else None)
    if not exe:
        return False, f"'{py}' was not found on PATH"
    hook = cfg / "hooks" / "log_tokens.py"
    reader = cfg / "skills" / "token-log" / "scripts" / "read_log.py"
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        transcript, log = td / "t.jsonl", td / "log.jsonl"
        env = dict(os.environ, CLAUDE_TOKEN_LOG=str(log), CLAUDE_TOKEN_PRICING="")
        env.pop("CLAUDE_TOKEN_PRICING")

        def add_message(mid, out):
            entry = {"type": "assistant", "message": {"id": mid, "model": "claude-sonnet-5-5", "content": [],
                     "usage": {"input_tokens": 5, "output_tokens": out, "cache_read_input_tokens": 100,
                               "cache_creation_input_tokens": 20}}}
            with open(transcript, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")

        def fire(tool):
            payload = json.dumps({"session_id": "selftest", "transcript_path": str(transcript),
                                  "hook_event_name": "PostToolUse", "tool_name": tool, "tool_input": {}})
            return subprocess.run([exe, str(hook)], input=payload, text=True, env=env,
                                  capture_output=True, timeout=60)

        def run_reader(*a):
            return subprocess.run([exe, str(reader), *a], text=True, env=env, capture_output=True, timeout=60)

        add_message("msg_1", 10)
        p = fire("Read")
        if p.returncode != 0 or not log.exists():
            return False, "the hook did not write a log line " + (p.stderr or "").strip()[:200]
        rec = json.loads(log.read_text(encoding="utf-8").splitlines()[0])
        if rec.get("context_tokens") != 125:
            return False, f"hook recorded unexpected data: {rec}"
        m = run_reader("--mark", "start", "--name", "selftest")
        if m.returncode != 0:
            return False, "reader failed on --mark: " + (m.stderr or m.stdout).strip()[:200]
        add_message("msg_2", 30)
        fire("Bash")
        r = run_reader("--report", "--name", "selftest", "--no-save")
        if r.returncode != 0 or "# Token window report" not in r.stdout:
            return False, "report failed: " + (r.stderr or r.stdout).strip()[:300]
        if "Estimated cost" not in r.stdout:
            return False, "report ran but the cost section is missing (pricing.json not found?)"
    return True, f"hook, reader and report work with '{py}'"


def choose_python(cfg, args):
    if args.python:
        ok, msg = (True, "not tested") if args.no_test else self_test(cfg, args.python)
        return args.python, ok, msg
    candidates = []
    for c in ("python3", "python", Path(sys.executable).as_posix()):
        if c not in candidates and (shutil.which(c) or Path(c).exists()):
            candidates.append(c)
    if args.no_test:
        return (candidates[0] if candidates else Path(sys.executable).as_posix()), True, "not tested"
    last = "no Python interpreter found"
    for c in candidates:
        ok, msg = self_test(cfg, c)
        if ok:
            return c, True, msg
        last = f"{c}: {msg}"
    return (candidates[0] if candidates else "python3"), False, last


# ---------------------------------------------------------------- commands
def adapt_commands(cfg, py):
    """Point the slash commands at this interpreter and config dir when they differ from the defaults."""
    default_dir = (Path.home() / ".claude").resolve()
    base = "~/.claude" if cfg == default_dir else cfg.as_posix()
    if py == "python3" and base == "~/.claude":
        return
    if " " in base:
        say(f"  note: {base} contains spaces; if a slash command fails, edit its python path by hand.")
    for f in (cfg / "commands").glob("token-*.md"):
        text = f.read_text(encoding="utf-8")
        f.write_text(text.replace("python3 ~/.claude", f"{q(py)} {base}"), encoding="utf-8")


# ---------------------------------------------------------------- actions
def do_install(args):
    cfg = config_dir(args)
    settings_path = cfg / "settings.json"
    settings = None if args.no_settings else load_settings(settings_path)  # fail before touching anything
    zf = open_payload()
    names = [n for n in zf.namelist() if not n.endswith("/")]

    if args.dry_run:
        say(f"[dry run] token-log kit {VERSION} -> {cfg}")
        for n in names:
            say(f"  write {safe_target(cfg, n)}")
        if settings is not None:
            trial = copy.deepcopy(settings)
            changed = add_hooks(trial, "<hook command>")
            say(f"  settings.json: {'hooks would be added' if changed else 'already up to date'}")
        say("[dry run] nothing was changed.")
        return 0

    say(f"Installing token-log kit {VERSION} into {cfg}")
    skill_dir = cfg / "skills" / "token-log"
    if skill_dir.exists():
        shutil.rmtree(skill_dir)
    for n in names:
        target = safe_target(cfg, n)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(zf.read(n))
        if not IS_WINDOWS and target.suffix == ".py":
            target.chmod(0o755)
    (skill_dir / "VERSION").write_text(VERSION + "\n", encoding="utf-8")
    say("  hook:     " + str(cfg / "hooks" / MARKER))
    say("  skill:    " + str(skill_dir))
    say("  commands: /token-start /token-end /token-span /token-report")

    py, ok, msg = choose_python(cfg, args)
    adapt_commands(cfg, py)
    if not ok:
        say(f"\nSelf-test FAILED: {msg}")
        say("Files are installed, but the hooks were NOT registered because the hook could not run.")
        say("Fix Python (or pass --python /full/path/to/python) and run the installer again.")
        return 1
    say(f"  self-test: {msg}")

    if settings is not None:
        hook_cmd = f"{q(py)} {q((cfg / 'hooks' / MARKER).as_posix())}"
        if add_hooks(settings, hook_cmd):
            save_settings(settings_path, settings)
            say("  settings: hooks registered in " + str(settings_path))
        else:
            say("  settings: already up to date")
    else:
        say("  settings: skipped (--no-settings); add PostToolUse and Stop hooks that run the hook script.")

    say("\nDone. Restart Claude Code, run any tool, then try:")
    say(f"  {q(py)} {q((skill_dir / 'scripts' / 'read_log.py').as_posix())} --summary")
    say(f"or type /token-start, work, then /token-report.  Log file: {log_path(cfg)}")
    return 0


def do_check(args):
    cfg = config_dir(args)
    say(f"token-log kit installer {VERSION} (built {BUILT}); config dir {cfg}")
    ver = cfg / "skills" / "token-log" / "VERSION"
    say(f"  installed version: {ver.read_text().strip() if ver.exists() else 'not installed'}")
    for label, p in (("hook", cfg / "hooks" / MARKER),
                     ("skill", cfg / "skills" / "token-log" / "SKILL.md"),
                     ("pricing", cfg / "skills" / "token-log" / "pricing.json")):
        say(f"  {label:<8} {'ok' if p.exists() else 'MISSING'}  {p}")
    cmds = sorted(f.name for f in (cfg / "commands").glob("token-*.md")) if (cfg / "commands").exists() else []
    say(f"  commands {', '.join(cmds) if cmds else 'MISSING'}")
    try:
        settings = load_settings(cfg / "settings.json")
    except SystemExit as e:
        say(f"  settings: {e}")
        return 1
    for event in EVENTS:
        reg = any(has_ours(g) for g in settings.get("hooks", {}).get(event, []))
        say(f"  hook registered for {event}: {'yes' if reg else 'NO'}")
    lp = log_path(cfg)
    if lp.exists():
        n = sum(1 for _ in open(lp, encoding="utf-8"))
        say(f"  log: {lp} ({n} line(s), {lp.stat().st_size:,} bytes)")
    else:
        say(f"  log: {lp} (not created yet; it appears after the first tool call)")
    return 0


def do_uninstall(args):
    cfg = config_dir(args)
    if args.purge and not args.yes:
        if sys.stdin.isatty():
            if input(f"Delete the token log and saved reports under {cfg}? [y/N] ").strip().lower() != "y":
                say("Cancelled.")
                return 1
        else:
            sys.exit("--purge deletes data; add --yes to confirm.")
    settings_path = cfg / "settings.json"
    if not args.no_settings and settings_path.exists():
        settings = load_settings(settings_path)
        if remove_hooks(settings):
            save_settings(settings_path, settings)
            say("  settings: hooks removed")
        else:
            say("  settings: no token-log hooks found")
    (cfg / "hooks" / MARKER).unlink(missing_ok=True) if sys.version_info >= (3, 8) else None
    shutil.rmtree(cfg / "skills" / "token-log", ignore_errors=True)
    for name in ("token-start", "token-end", "token-span", "token-report"):
        (cfg / "commands" / f"{name}.md").unlink(missing_ok=True)
    say("Removed hook, skill and slash commands.")
    if args.purge:
        log_path(cfg).unlink(missing_ok=True)
        shutil.rmtree(cfg / "token-reports", ignore_errors=True)
        say("Deleted the log and saved reports.")
    else:
        say(f"Kept the log at {log_path(cfg)} (use --purge --yes to delete it).")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Install the token-log kit for Claude Code.")
    ap.add_argument("--config-dir")
    ap.add_argument("--python")
    ap.add_argument("--no-settings", action="store_true")
    ap.add_argument("--no-test", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--uninstall", action="store_true")
    ap.add_argument("--purge", action="store_true")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--version", action="store_true")
    args = ap.parse_args()
    if args.version:
        say(f"token-log kit installer {VERSION} (built {BUILT})")
        return 0
    if args.check:
        return do_check(args)
    if args.uninstall:
        return do_uninstall(args)
    return do_install(args)


if __name__ == "__main__":
    sys.exit(main())
