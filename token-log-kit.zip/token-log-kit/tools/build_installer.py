#!/usr/bin/env python3
"""Build the single-file installer from this kit.

Usage:  python3 tools/build_installer.py [--out install_token_log.py]

Packs hooks/, skills/token-log/ and commands/token-*.md into a deterministic zip,
embeds it (base64 + SHA-256) in tools/installer_template.py and writes one file
that installs everything with no unzip step. Re-run it after editing the kit
(for example pricing.json) to refresh the installer.
"""
import argparse
import base64
import hashlib
import io
import textwrap
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INCLUDE = [("hooks", None), ("skills/token-log", None), ("commands", "token-*.md")]


def collect():
    files = []
    for rel, pattern in INCLUDE:
        base = ROOT / rel
        found = base.glob(pattern) if pattern else (p for p in base.rglob("*") if p.is_file())
        for p in sorted(found):
            if "__pycache__" in p.parts or p.suffix == ".pyc" or p.name == "VERSION":
                continue
            files.append(p)
    return files


def build_zip(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            info = zipfile.ZipInfo(p.relative_to(ROOT).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, p.read_bytes())
    return buf.getvalue()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "install_token_log.py"))
    a = ap.parse_args()

    version_file = ROOT / "VERSION"
    version = version_file.read_text().strip() if version_file.exists() else "1.0.0"
    data = build_zip(collect())
    b64 = "\n".join(textwrap.wrap(base64.b64encode(data).decode(), 100))

    template = (ROOT / "tools" / "installer_template.py").read_text(encoding="utf-8")
    out = (template.replace("__VERSION__", version)
                   .replace("__BUILT__", time.strftime("%Y-%m-%d"))
                   .replace("__SHA256__", hashlib.sha256(data).hexdigest())
                   .replace("__PAYLOAD__", b64))
    Path(a.out).write_text(out, encoding="utf-8")
    Path(a.out).chmod(0o755)
    print(f"built {a.out}: version {version}, {len(collect())} files, payload {len(data):,} bytes")


if __name__ == "__main__":
    main()
