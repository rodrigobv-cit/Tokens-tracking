#!/usr/bin/env python3
"""Add or remove the token-log hooks in a Claude Code settings.json.

Usage: settings_hooks.py add|remove <settings.json> <hook-command>

- Keeps every other setting and hook untouched.
- Idempotent: adding twice does not duplicate; removing only deletes entries
  whose command contains 'log_tokens.py'.
- Writes a timestamped backup next to the file before changing it.
"""
import json
import shutil
import sys
import time
from pathlib import Path

MARKER = "log_tokens.py"
EVENTS = ["PostToolUse", "Stop"]


def has_ours(group):
    return any(MARKER in h.get("command", "") for h in group.get("hooks", []))


def add(settings, command):
    hooks = settings.setdefault("hooks", {})
    changed = False
    for event in EVENTS:
        groups = hooks.setdefault(event, [])
        if any(has_ours(g) for g in groups):
            continue
        group = {"hooks": [{"type": "command", "command": command}]}
        if event == "PostToolUse":
            group["matcher"] = "*"
        groups.append(group)
        changed = True
    return changed


def remove(settings):
    hooks = settings.get("hooks", {})
    changed = False
    for event in list(hooks):
        kept = []
        for g in hooks[event]:
            if has_ours(g):
                rest = [h for h in g["hooks"] if MARKER not in h.get("command", "")]
                changed = True
                if rest:
                    g = dict(g, hooks=rest)
                    kept.append(g)
            else:
                kept.append(g)
        if kept:
            hooks[event] = kept
        else:
            del hooks[event]
    if not hooks:
        settings.pop("hooks", None)
    return changed


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in ("add", "remove"):
        sys.exit(__doc__)
    mode, path = sys.argv[1], Path(sys.argv[2])
    command = sys.argv[3] if len(sys.argv) > 3 else ""

    if path.exists() and path.read_text().strip():
        try:
            settings = json.loads(path.read_text())
        except json.JSONDecodeError as e:
            sys.exit(f"{path} is not valid JSON ({e}). Fix it or add the hooks by hand; nothing was changed.")
    else:
        if mode == "remove":
            print("settings.json not found, nothing to remove")
            return
        settings = {}

    changed = add(settings, command) if mode == "add" else remove(settings)
    if not changed:
        print("settings.json already up to date" if mode == "add" else "no token-log hooks found in settings.json")
        return

    if path.exists():
        backup = path.with_name(f"{path.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}")
        shutil.copy2(path, backup)
        print(f"backup: {backup}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2, ensure_ascii=False) + "\n")
    print("settings.json updated")


if __name__ == "__main__":
    main()
