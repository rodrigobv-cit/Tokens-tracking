#!/usr/bin/env bash
# Removes the token-log kit from ~/.claude. Keeps your log unless --purge is given.
# Usage: bash uninstall.sh [--purge]
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"

python3 "$SRC/tools/settings_hooks.py" remove "$CLAUDE_DIR/settings.json"
rm -f "$CLAUDE_DIR/hooks/log_tokens.py"
rm -rf "$CLAUDE_DIR/skills/token-log"
rm -f "$CLAUDE_DIR/commands/token-start.md" "$CLAUDE_DIR/commands/token-end.md" "$CLAUDE_DIR/commands/token-span.md" "$CLAUDE_DIR/commands/token-report.md"
echo "Removed hook, skill and slash commands."

if [ "${1:-}" = "--purge" ]; then
  rm -f "${CLAUDE_TOKEN_LOG:-$CLAUDE_DIR/token-log.jsonl}"
  echo "Deleted the log file."
else
  echo "Kept the log at ${CLAUDE_TOKEN_LOG:-$CLAUDE_DIR/token-log.jsonl} (use --purge to delete it)."
fi
