#!/usr/bin/env python3
"""Build post.html (self-contained, images embedded as data URIs) from the diagrams."""
import base64
from pathlib import Path

ROOT = Path(__file__).resolve().parent
D = ROOT / "diagrams"


def img(name, alt, caption, slot):
    b64 = base64.b64encode((D / f"{name}.png").read_bytes()).decode()
    return (f'<!-- MEDIUM: upload diagrams/{name}.png here ({slot}) -->\n'
            f'<figure><img src="data:image/png;base64,{b64}" alt="{alt}">'
            f'<figcaption>{caption}</figcaption></figure>')


BODY = f"""
<h1>I Was Burning Claude Code Tokens Blind. So I Built a Flight Recorder.</h1>
<h2>A tiny, free toolkit that tells you where your tokens went, what they would cost, and how to spend fewer</h2>

<p><em>[Your name] · [N] min read</em></p>

<p>Picture this. You spend an hour with Claude Code, refactoring something gnarly. It goes great. Then you look at your usage and think: <strong>"...where did all of that go?"</strong></p>

<p>I had that feeling a few too many times. Claude Code is wonderful, but it is a black box when it comes to tokens. Which skill was the heavy one? Did my coffee break quietly cost me money? Is prompt caching even helping?</p>

<p>So (with Claude's help, naturally) I built a small kit that records every tool call, lets me mark a start and an end, and spits out a report. Here is how it works and how you can use it in about five minutes.</p>

<h2>What you get</h2>

<ul>
<li><strong>Exact token counts</strong> per tool call, read from the session transcript, not guessed.</li>
<li><strong>Start and end markers</strong>, so you can measure exactly one task.</li>
<li><strong>A report</strong> with skills used (in order), window time, permission mode, model, effort, and caching details.</li>
<li><strong>A cost estimate</strong> at API list prices, priced per message with that message's own model.</li>
<li><strong>Skills flow and tool flow diagrams</strong>, so you can literally see what happened.</li>
<li><strong>Optimization tips</strong>, but only the ones your own data justifies.</li>
</ul>

<p>Everything is local. No network calls, no dependencies beyond Python's standard library.</p>

<h2>How it works (the 30-second version)</h2>

<p>Claude Code supports <em>hooks</em>: small scripts that run at certain moments. Mine runs after every tool call, peeks at the session transcript (where the real token counts already live), and appends one line to a log file. Slash commands drop markers into that same log, and a reader script turns the log into reports.</p>

{img("01-how-it-works", "Diagram: Claude Code triggers a hook after every tool call, the hook appends to a log, and the log feeds the report. Slash commands add markers and request reports.", "The whole system: a hook feeds a log, and a reader turns the log into a report.", "after the paragraph above")}

<p>That is it. No magic, no proxy sitting between you and the API.</p>

<h2>Install in one command</h2>

<p>The kit ships as a single file, <code>install_token_log.py</code>, with everything embedded and verified by a checksum. Nothing to unzip:</p>

<pre>python3 install_token_log.py              # install or update
python3 install_token_log.py --dry-run    # preview, change nothing
python3 install_token_log.py --check      # see what is installed
python3 install_token_log.py --uninstall  # remove it (keeps your log)</pre>

<p>A few things I cared about when writing the installer:</p>

<ul>
<li>It <strong>backs up your <code>settings.json</code></strong> before touching it, and merges instead of overwriting.</li>
<li>It <strong>runs a self-test</strong> (hook, reader, report) before registering anything. If the test fails, it installs the files but leaves your hooks alone and tells you why.</li>
<li>Re-running it is safe.</li>
</ul>

<p>Restart Claude Code afterwards and you are set.</p>

<blockquote>Heads up: I tested everything on macOS/Linux-style setups with synthetic data. Windows support is untested. If something breaks there, <code>--python</code> and <code>--no-settings</code> are your escape hatches.</blockquote>

<h2>The three-command ritual</h2>

<p>This is the part you will actually use:</p>

<pre>/token-start refactor      # drop a marker
... do your normal work ...
/token-end refactor        # tokens consumed between the marks
/token-report refactor     # the full report</pre>

<p>Give the window a name if you like, or skip it and it uses "default". Need a peek mid-task without closing the window? <code>/token-span</code> shows the running total.</p>

{img("02-three-commands", "Diagram: a timeline with a start marker, a sequence of tool and skill calls, and an end marker, producing a report.", "Everything between the two markers gets counted: tokens, skills, tools.", "right after the commands")}

<h2>Reading the report</h2>

<p>The report is plain markdown, saved to <code>~/.claude/token-reports/</code>. Here is the map of what is inside:</p>

{img("03-report-anatomy", "Diagram: the seven sections of the report with a short explanation of each.", "Seven sections, each answering one question. The numbers shown are from a synthetic example.", "report overview")}

<p>The sections I look at first:</p>

<ul>
<li><strong>Window:</strong> total time, split into active and idle. Idle time is a quiet hint that your cache may have expired.</li>
<li><strong>Tokens:</strong> new tokens versus cache reads. Cache reads are the cheap ones; new input and output are where the money goes.</li>
<li><strong>Estimated cost:</strong> broken down by output, input, cache writes and cache reads.</li>
<li><strong>Caching:</strong> hit rate and how much the cache saved you.</li>
</ul>

<h2>Seeing the flow</h2>

<p>My favorite part. The report draws two flows: the order your <strong>skills</strong> ran in, and the order of every <strong>tool</strong> call, with time and context growth on each step.</p>

{img("04-skills-and-tool-flow", "Diagram: an example skills flow, tool flow and a to-scale timeline in which one long pause dominates the window.", "An illustrative example. Notice how one long pause swallows most of the window.", "flows")}

<p>In the report file itself these are Mermaid diagrams, which GitHub and VS Code's Markdown preview render automatically. Everywhere else you will see the diagram source plus a plain table with the same facts.</p>

<h2>The cache plot twist</h2>

<p>This one surprised me. Prompt caching makes re-reading your context cheap, but the default cache only lives for a few minutes. Step away for a long coffee, come back, and your next message may pay to write the <em>entire</em> context into the cache again.</p>

{img("05-cache-expiry", "Diagram: comparing a 5-minute cache that expires during a 13-minute break with a 1-hour cache that survives it.", "Why a long break can make your next turn expensive.", "cache section")}

<p>The report checks for exactly this. If it sees a long pause followed by a big cache write, it flags it and shows the evidence. Whether a longer cache lifetime is available depends on your setup, so check the current docs for your plan before relying on it.</p>

<h2>About the cost number</h2>

<p>Quick honesty section, because cost numbers are easy to misread:</p>

<ul>
<li>Prices come from a <code>pricing.json</code> file based on the <a href="https://platform.claude.com/docs/en/about-claude/pricing">official pricing page</a> (retrieved 2026-10-31). Prices change, so edit the file when they do.</li>
<li>If you are on a Pro, Max or Team subscription, you are not billed per token. Read the figure as "what this would cost at API prices".</li>
<li>It leaves out fast mode, data residency and batch multipliers, and server-side web tool fees.</li>
<li>A model that is not in the table shows up as "Not priced" instead of a made-up number.</li>
</ul>

<h2>The tips (and why I trust them a bit)</h2>

<p>The suggestions are rule-based, not vibes. Each tip shows the evidence it measured and what to do about it. The rules cover things like:</p>

<ul>
<li>Cache expiry during pauses</li>
<li>Switching models in the middle of a task</li>
<li>Context compaction</li>
<li>Heavy skills that add a lot of context</li>
<li>Huge tool outputs</li>
<li>A big model doing routine work</li>
</ul>

<p>They are heuristics from one window, not guarantees. Treat them as "worth a look", not gospel.</p>

<h2>My honest limits list</h2>

<ul>
<li>It was tested on synthetic data and simulated sessions. Please try it on a real session and tell me what breaks.</li>
<li>Effort level and permission mode come from the hook payload, and a couple of environment variable names for caching come from unofficial sources. Verify them on your version.</li>
<li>Settings that live only in <code>settings.json</code> are not visible to the hook.</li>
<li>Durations run until the next step starts, so they include your own thinking and pauses.</li>
</ul>

<h2>Try it</h2>

<p>Install it, run one <code>/token-start</code> and <code>/token-report</code> around your next task, and look at the cache section first. I would be surprised if it does not teach you something about your own habits.</p>

<p>[Link to the repo or download here]</p>

<p>If you try it and find a bug or a better rule for the tips, tell me. I would love to hear what your first report showed.</p>

<p><em>I built this with Claude's help.</em></p>
"""

CSS = """
body{max-width:720px;margin:40px auto;padding:0 20px;font-family:Georgia,'Times New Roman',serif;font-size:20px;line-height:1.6;color:#242424;background:#fff}
h1{font-family:Helvetica,Arial,sans-serif;font-size:40px;line-height:1.15;margin:0 0 12px}
h2{font-family:Helvetica,Arial,sans-serif;font-size:26px;margin:44px 0 12px}
h1+h2{font-size:22px;font-weight:400;color:#6b6b6b;margin-top:0}
figure{margin:32px -60px}
figure img{width:100%;height:auto;display:block}
figcaption{text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:14px;color:#6b6b6b;margin-top:8px}
pre{background:#f5f5f5;padding:16px;overflow-x:auto;font-size:15px;line-height:1.5;border-radius:6px}
code{background:#f5f5f5;padding:2px 5px;border-radius:4px;font-size:.85em}
pre code{padding:0;background:none}
blockquote{border-left:3px solid #242424;margin:24px 0;padding-left:20px;font-style:italic}
@media(max-width:800px){figure{margin:32px 0}}
"""

html = (f'<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        f'<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>I Was Burning Claude Code Tokens Blind</title><style>{CSS}</style></head>'
        f'<body>\n{BODY}\n</body></html>')
(ROOT / "post.html").write_text(html, encoding="utf-8")
print("post.html", len(html) // 1024, "KB")
