#!/usr/bin/env python3
"""Generate the five diagrams for the Medium post as SVG (one consistent style)."""
from pathlib import Path

OUT = Path(__file__).resolve().parent / "diagrams"
OUT.mkdir(exist_ok=True)

FONT = "Inter, 'Helvetica Neue', Arial, sans-serif"
MONO = "'DejaVu Sans Mono', 'SFMono-Regular', Menlo, monospace"
INK, MUTED, LINE = "#0f172a", "#64748b", "#cbd5e1"
COL = {  # fill, stroke
    "blue": ("#dbeafe", "#2563eb"), "amber": ("#fef3c7", "#d97706"), "green": ("#d1fae5", "#059669"),
    "violet": ("#ede9fe", "#7c3aed"), "rose": ("#ffe4e6", "#e11d48"), "slate": ("#f1f5f9", "#94a3b8"),
}


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.parts, self.markers = w, h, [], {}

    def marker(self, color):
        if color not in self.markers:
            self.markers[color] = f"ah{len(self.markers)}"
        return self.markers[color]

    def rect(self, x, y, w, h, color="slate", rx=16, sw=2.5, dashed=False, fill=None, stroke=None):
        f, s = COL[color] if color else (None, None)
        f, s = fill or f, stroke or s
        d = ' stroke-dasharray="8 6"' if dashed else ""
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{f}" stroke="{s}" stroke-width="{sw}"{d}/>')

    def text(self, x, y, t, size=18, weight=400, fill=INK, anchor="middle", mono=False, italic=False):
        fam = MONO if mono else FONT
        st = ' font-style="italic"' if italic else ""
        self.parts.append(f'<text x="{x}" y="{y}" font-family="{fam}" font-size="{size}" font-weight="{weight}" '
                          f'fill="{fill}" text-anchor="{anchor}"{st}>{esc(t)}</text>')

    def lines(self, x, y, ts, size=15, weight=400, fill=MUTED, anchor="middle", lh=1.35, mono=False):
        for i, t in enumerate(ts):
            self.text(x, y + i * size * lh, t, size, weight, fill, anchor, mono)

    def arrow(self, x1, y1, x2, y2, color=MUTED, sw=3, dashed=False):
        m = self.marker(color)
        d = ' stroke-dasharray="7 6"' if dashed else ""
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}" '
                          f'stroke-linecap="round"{d} marker-end="url(#{m})"/>')

    def line(self, x1, y1, x2, y2, color=LINE, sw=3, dashed=False):
        d = ' stroke-dasharray="6 6"' if dashed else ""
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{sw}" stroke-linecap="round"{d}/>')

    def circle(self, cx, cy, r, color="blue", sw=0):
        f, s = COL[color]
        self.parts.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{s}" stroke="{s}" stroke-width="{sw}"/>')

    def render(self):
        defs = "".join(
            f'<marker id="{i}" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="6" markerHeight="6" orient="auto">'
            f'<path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>' for c, i in self.markers.items())
        return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}">'
                f'<defs>{defs}</defs><rect width="{self.w}" height="{self.h}" fill="#ffffff"/>' + "".join(self.parts) + "</svg>")

    def save(self, name):
        (OUT / f"{name}.svg").write_text(self.render(), encoding="utf-8")


def box(s, x, y, w, h, color, title, sub, tsize=22, ssize=15):
    s.rect(x, y, w, h, color)
    stroke = COL[color][1]
    s.text(x + w / 2, y + 50, title, tsize, 700, INK)
    s.lines(x + w / 2, y + 82, sub, ssize, 400, MUTED)


# ---------------------------------------------------------------- 1. how it works
def d1():
    s = Svg(1200, 640)
    xs, y, w, h = [40, 340, 640, 940], 200, 210, 150
    box(s, xs[0], y, w, h, "slate", "Claude Code", ["your normal session:", "tools, skills, subagents"])
    box(s, xs[1], y, w, h, "blue", "The hook", ["log_tokens.py", "tiny Python script"])
    box(s, xs[2], y, w, h, "amber", "The log", ["token-log.jsonl", "one line per tool call"])
    box(s, xs[3], y, w, h, "green", "The report", ["cost, flows,", "optimization tips"])
    for i, lab in enumerate((["after every", "tool call"], ["appends", "a line"], ["read when", "you ask"])):
        gx1, gx2 = xs[i] + w + 6, xs[i + 1] - 6
        s.arrow(gx1, y + 75, gx2, y + 75, MUTED)
        s.lines((gx1 + gx2) / 2, y + 45, lab, 13, 500, MUTED)
    # transcript lane
    s.rect(90, 450, 420, 86, "violet")
    s.text(300, 490, "The session transcript", 20, 700, INK)
    s.text(300, 516, "where the real token counts already live", 15, 400, MUTED)
    s.arrow(145, y + h + 4, 145, 444, COL["violet"][1])
    s.text(160, 410, "Claude Code writes it", 14, 500, MUTED, "start")
    s.arrow(445, 444, 445, y + h + 4, COL["violet"][1])
    s.text(460, 410, "hook reads exact usage", 14, 500, MUTED, "start")
    # slash commands
    s.rect(660, 40, 490, 74, "rose")
    s.text(905, 84, "/token-start   /token-end   /token-report", 19, 700, INK, mono=True)
    s.arrow(745, 118, 745, y - 6, COL["rose"][1])
    s.text(760, 160, "drop start / end markers", 14, 500, MUTED, "start")
    s.arrow(1045, 118, 1045, y - 6, COL["rose"][1])
    s.text(1060, 160, "ask for a report", 14, 500, MUTED, "start")
    s.text(600, 596, "All local. No network calls, no extra dependencies, just the Python standard library.", 17, 500, MUTED)
    s.save("01-how-it-works")


# ---------------------------------------------------------------- 2. the ritual
def d2():
    s = Svg(1200, 480)
    for cx, label in ((170, "mark the start"), (600, "work like you always do"), (1030, "close it, get the report")):
        s.circle(cx, 46, 17, "blue")
    for cx, n in ((170, "1"), (600, "2"), (1030, "3")):
        s.text(cx, 52, n, 17, 700, "#ffffff")
    for cx, label in ((170, "mark the start"), (600, "work like you always do"), (1030, "close it, get the report")):
        s.text(cx, 96, label, 19, 700, INK)
    s.line(90, 240, 1110, 240, LINE, 8)
    s.rect(140, 196, 60, 88, "green", rx=30, sw=0, fill=COL["green"][1])
    s.text(170, 247, "▶", 22, 700, "#ffffff")
    s.rect(1000, 196, 60, 88, "violet", rx=30, sw=0, fill=COL["violet"][1])
    s.text(1030, 247, "■", 20, 700, "#ffffff")
    s.text(170, 154, "/token-start refactor", 17, 700, COL["green"][1], mono=True)
    s.text(1030, 154, "/token-end refactor", 17, 700, COL["violet"][1], mono=True)
    chips = [("Read", "blue", 228, 78), ("Skill: pdf", "amber", 318, 128), ("Bash", "blue", 458, 78),
             ("Edit", "blue", 548, 78), ("Read", "blue", 638, 78), ("Skill: design", "amber", 728, 150), ("Edit", "blue", 890, 78)]
    for t, c, x, w in chips:
        s.rect(x, 218, w, 44, c, rx=22, sw=2)
        s.text(x + w / 2, 247, t, 15, 600, INK)
    # bracket
    s.line(170, 318, 1030, 318, COL["blue"][1], 4)
    s.line(170, 304, 170, 318, COL["blue"][1], 4)
    s.line(1030, 304, 1030, 318, COL["blue"][1], 4)
    s.text(600, 358, "your window: every token, skill and tool call in here gets counted", 18, 500, MUTED)
    s.rect(300, 392, 600, 62, "green")
    s.text(600, 430, "Report: tokens · cost · skills flow · tool flow · tips", 19, 700, INK)
    s.save("02-three-commands")


# ---------------------------------------------------------------- 3. report anatomy
def d3():
    s = Svg(1200, 770)
    rows = [
        ("blue", "Window", "16m 50s · active 5m · idle 11m · plan → accept edits", "How long, in which mode, on which model and effort"),
        ("green", "Tokens", "12,730 new · 121,770 cache reads · context 30k → 10k", "What you actually consumed, split into new work and re-read context"),
        ("amber", "Estimated cost", "$0.66 = output + input + cache write + cache read", "What the same usage would cost at API list prices"),
        ("violet", "Caching", "hit rate 47% · 5m / 1h writes · saved 24%", "Is the cache earning its keep, or are you paying twice?"),
        ("amber", "Skills flow", "Start → pdf → design → End", "Which skills ran, in order, and the context each one added"),
        ("blue", "Tool flow", "Read → Skill → Read → Bash ×2 → Edit ×2", "Every step with time, context growth and output tokens"),
        ("rose", "Suggestions", "5 tips, each with the evidence behind it", "Rule-based, and only when your data shows the problem"),
    ]
    s.rect(30, 20, 640, 730, "slate", rx=22, sw=2, fill="#ffffff", stroke=LINE)
    for i, (c, title, content, note) in enumerate(rows):
        y = 44 + i * 100
        s.rect(52, y, 596, 86, c, rx=14, sw=1.5)
        s.rect(52, y, 10, 86, c, rx=5, sw=0, fill=COL[c][1])
        s.text(84, y + 34, title, 19, 700, INK, "start")
        s.text(84, y + 62, content, 14.5, 400, MUTED, "start")
        s.line(652, y + 43, 712, y + 43, COL[c][1], 3, dashed=True)
        s.circle(718, y + 43, 6, c)
        s.text(738, y + 38, note.split(", ")[0] if False else "", 1)
        words, line1, line2 = note.split(" "), "", ""
        for wd in words:
            if len(line1) + len(wd) < 36 and not line2:
                line1 += (" " if line1 else "") + wd
            else:
                line2 += (" " if line2 else "") + wd
        if line2:
            s.text(738, y + 38, line1, 16.5, 500, INK, "start")
            s.text(738, y + 62, line2, 16.5, 500, INK, "start")
        else:
            s.text(738, y + 50, line1, 16.5, 500, INK, "start")
    s.save("03-report-anatomy")


# ---------------------------------------------------------------- 4. flows
def d4():
    s = Svg(1200, 640)
    s.text(40, 44, "SKILLS FLOW", 15, 700, MUTED, "start")
    s.rect(40, 100, 110, 64, "slate", rx=32)
    s.text(95, 140, "Start", 18, 600, INK)
    s.rect(300, 76, 250, 112, "amber")
    s.text(425, 112, "pdf", 22, 700, INK)
    s.lines(425, 140, ["+1m 00s · 14m 50s", "~8,000 tokens of context"], 14.5)
    s.rect(710, 76, 250, 112, "amber")
    s.text(835, 112, "design", 22, 700, INK)
    s.lines(835, 140, ["+15m 50s · 1m 10s", "~5,000 tokens of context"], 14.5)
    s.rect(1050, 100, 110, 64, "slate", rx=32)
    s.text(1105, 140, "End", 18, 600, INK)
    s.arrow(152, 132, 296, 132); s.text(224, 118, "Read", 14, 500, MUTED)
    s.arrow(552, 132, 706, 132); s.text(629, 108, "Read, Bash ×2", 14, 500, MUTED)
    s.arrow(962, 132, 1046, 132); s.text(1004, 118, "Edit ×2", 14, 500, MUTED)

    s.text(40, 270, "TOOL FLOW", 15, 700, MUTED, "start")
    steps = [("Read", "blue", "40s"), ("Skill: pdf", "amber", "30s"), ("Read", "blue", "30s"),
             ("Bash ×2", "blue", "13m 50s"), ("Skill: design", "amber", "40s"), ("Edit ×2", "blue", "30s")]
    x = 40
    for i, (t, c, d) in enumerate(steps):
        s.rect(x, 296, 160, 62, c, rx=14)
        s.text(x + 80, 334, t, 16.5, 600, INK)
        s.text(x + 80, 384, d, 14.5, 500, MUTED)
        if i < len(steps) - 1:
            s.arrow(x + 163, 327, x + 188, 327, MUTED, 2.5)
        x += 186
    s.text(40, 452, "THE SAME WINDOW, DRAWN TO SCALE", 15, 700, MUTED, "start")
    total, scale, x = 1000.0, 1120.0, 40.0
    secs = [40, 30, 30, 830, 40, 30]
    for (t, c, d), sec in zip(steps, secs):
        w = scale * sec / total
        if t.startswith("Bash"):
            s.rect(x, 478, w, 54, "slate", rx=8, sw=1.5, dashed=True)
            s.text(x + w / 2, 512, "mostly a pause: you were away from the keyboard", 16, 500, MUTED)
        else:
            s.rect(x, 478, max(w, 4), 54, c, rx=4, sw=1)
        x += w
    s.text(600, 580, "Durations run until the next step starts, so they include your own pauses.", 15, 500, MUTED)
    s.save("04-skills-and-tool-flow")


# ---------------------------------------------------------------- 5. cache expiry
def d5():
    s = Svg(1200, 600)
    s.text(40, 46, "DEFAULT: 5-MINUTE CACHE", 15, 700, MUTED, "start")
    s.rect(40, 70, 250, 74, "green")
    s.text(165, 103, "Context written to cache", 17, 700, INK)
    s.text(165, 126, "about 1.25× the input price", 14, 400, MUTED)
    for i in range(6):
        s.rect(318 + i * 42, 86, 32, 42, "green", rx=6, sw=1.5)
    s.text(318 + 3 * 42 - 5, 168, "cheap cache reads (a fraction of the input price)", 14, 500, MUTED)
    s.rect(580, 70, 250, 74, "slate", dashed=True, sw=2)
    s.text(705, 103, "You step away", 17, 700, INK)
    s.text(705, 126, "13 minutes", 14, 400, MUTED)
    s.line(630, 150, 630, 190, COL["rose"][1], 3, dashed=True)
    s.text(636, 206, "5-minute cache lifetime ends here", 14, 600, COL["rose"][1], "start")
    s.arrow(832, 107, 866, 107, MUTED)
    s.rect(870, 70, 290, 74, "rose")
    s.text(1015, 103, "Context written AGAIN", 17, 700, INK)
    s.text(1015, 126, "full write price, for the whole context", 14, 400, MUTED)

    s.line(40, 262, 1160, 262, LINE, 2)
    s.text(40, 306, "WITH THE 1-HOUR CACHE", 15, 700, MUTED, "start")
    s.rect(40, 330, 250, 74, "green")
    s.text(165, 363, "Context written to cache", 17, 700, INK)
    s.text(165, 386, "about 2× the input price, once", 14, 400, MUTED)
    for i in range(6):
        s.rect(318 + i * 42, 346, 32, 42, "green", rx=6, sw=1.5)
    s.rect(580, 330, 250, 74, "slate", dashed=True, sw=2)
    s.text(705, 363, "You step away", 17, 700, INK)
    s.text(705, 386, "13 minutes", 14, 400, MUTED)
    s.arrow(832, 367, 866, 367, MUTED)
    for i in range(7):
        s.rect(870 + i * 42, 346, 32, 42, "green", rx=6, sw=1.5)
    s.text(1015, 428, "still cached: back to cheap reads", 14, 600, COL["green"][1])

    s.rect(40, 476, 1120, 80, "amber", rx=18)
    s.text(600, 510, "Takeaway: a pause longer than the cache lifetime makes your next turn pay full price again.", 18, 700, INK)
    s.text(600, 538, "Keep breaks short, or ask for the longer cache if your setup supports it.", 16, 400, MUTED)
    s.save("05-cache-expiry")


if __name__ == "__main__":
    for f in (d1, d2, d3, d4, d5):
        f()
    print("wrote", ", ".join(sorted(p.name for p in OUT.glob("*.svg"))))
