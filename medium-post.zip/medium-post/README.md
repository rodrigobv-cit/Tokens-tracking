# Medium post draft

- `post.html`: the draft, self-contained (images embedded). Open it in a browser to preview.
- `diagrams/*.png`: the 5 diagrams at 2400px wide; `*.svg` are the sources.
- `make_diagrams.py` / `build_post.py`: regenerate diagrams and post.

## Getting it into Medium
Medium has no HTML import for embedded images, so:
1. Open `post.html` in a browser, select all, copy, and paste into a new Medium story. Headings, lists, quotes and code blocks carry over.
2. Embedded images usually do not survive the paste. Delete any broken image, then upload the matching PNG from `diagrams/` at the spot marked in the HTML comments (the order in the post is 01 to 05).
3. Replace the placeholders: `[Your name]`, `[N] min read`, `[Link to the repo or download here]`.
4. Optionally add your own real report numbers; the diagram figures are synthetic examples.

## Check before publishing
- Test the kit on a real session; it was only tested on synthetic data.
- Cache env var names and the effort field come from unofficial sources.
- Windows is untested.
